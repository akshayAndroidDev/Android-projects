package com.example.databasedemo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {

            SQLiteDatabase sqLiteDatabase = this.openOrCreateDatabase("Users", MODE_PRIVATE, null);

            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS theNewUsers (id INTEGER PRIMARY KEY,name VARCHAR , age INT(3))");

            //sqLiteDatabase.execSQL("INSERT INTO theNewUsers(name,age) values('Ann',50)");
            //sqLiteDatabase.execSQL("INSERT INTO theNewUsers(name,age) values('This',15)");
            //sqLiteDatabase.execSQL("INSERT INTO theNewUsers(name,age) values('That',20)");

            sqLiteDatabase.execSQL("DELETE FROM theNewUsers WHERE id = 1");

            Cursor c = sqLiteDatabase.rawQuery("SELECT * FROM theNewUsers", null);

            int idIndex = c.getColumnIndex("id");
            int nameIndex = c.getColumnIndex("name");
            int ageIndex = c.getColumnIndex("age");

            c.moveToFirst();

            while (c != null) {
                Log.i("id",Integer.toString(c.getInt(idIndex)));
                Log.i("name", c.getString(nameIndex));
                Log.i("age", Integer.toString(c.getInt(ageIndex)));

                c.moveToNext();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
